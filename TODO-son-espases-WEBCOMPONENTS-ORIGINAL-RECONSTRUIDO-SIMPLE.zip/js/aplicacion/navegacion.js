(() => {
  const VISTAS = {
    login: 'componentes/login.html', inicio: 'componentes/inicio.html', clase: 'componentes/clase.html',
    asignaturas: 'componentes/asignaturas.html', asignatura: 'componentes/asignatura.html',
    apuntes: 'componentes/apuntes.html', documentos: 'componentes/documentos.html', visor: 'componentes/visor.html'
  };
  const scriptsCargados = new Set();
  const estilosCargados = new Set();
  let cargaActual = Promise.resolve();
  function normalizar(url){ return new URL(url, document.baseURI).href; }
  async function cargarScript(src){
    if(!src || scriptsCargados.has(normalizar(src))) return;
    const url=normalizar(src);
    if(scriptsCargados.has(url)) return;
    await new Promise((resolve,reject)=>{ const s=document.createElement('script'); s.src=url; s.onload=()=>{scriptsCargados.add(url);resolve();}; s.onerror=()=>reject(new Error('No se pudo cargar '+src)); document.head.appendChild(s); });
  }
  function prepararEstilos(contenedor){
    contenedor.querySelectorAll('link[rel="stylesheet"]').forEach(link=>{
      const href=link.href; if(!href || estilosCargados.has(href)) return;
      estilosCargados.add(href); document.head.appendChild(link.cloneNode(true));
    });
    contenedor.querySelectorAll('link[rel="stylesheet"]').forEach(x=>x.remove());
  }
  async function cargar(vista, contexto={}){
    if(!VISTAS[vista]) throw new Error('Vista no registrada: '+vista);
    cargaActual=cargaActual.then(async()=>{
      window.__VISTA_ACTUAL=vista; window.__CONTEXTO_VISTA=contexto||{};
      if(window.Estado?.guardarContexto) window.Estado.guardarContexto(contexto||{});
      for(const [k,v] of Object.entries(contexto||{})){ if(v!==undefined && v!==null && v!=='') window.Estado?.guardar?.(k,v); }
      const r=await fetch(VISTAS[vista],{cache:'no-store'}); if(!r.ok) throw new Error(`No se pudo cargar ${VISTAS[vista]}`);
      const html=await r.text(); const tmp=document.createElement('div'); tmp.innerHTML=html;
      const scripts=[...tmp.querySelectorAll('script[data-componente-script]')].map(s=>s.getAttribute('src')).filter(Boolean); scripts.forEach(s=>s&&s.startsWith('/') ? null : null);
      const app=document.getElementById('contenido'); if(!app) throw new Error('Falta #contenido');
      app.replaceChildren(...[...tmp.childNodes].filter(n=>!(n.nodeType===1&&n.matches('script[data-componente-script]'))));
      prepararEstilos(app);
      for(const s of scripts) await cargarScript(s);
      window.dispatchEvent(new CustomEvent('vista-cargada',{detail:{vista,contexto}}));
    });
    return cargaActual;
  }
  function navegar(ruta,contexto={}){
    const s=String(ruta||''); let vista='inicio';
    if(s.includes('iniciar-sesion')) vista='login'; else if(s.includes('visor-admin')) vista='visor'; else if(s.includes('visualizar-documentos')) vista='documentos'; else if(s.includes('/apuntes')) vista='apuntes'; else if(s.includes('/asignatura.html')) vista='asignatura'; else if(s.includes('/asignaturas.html')) vista='asignaturas'; else if(s.includes('/clase.html')) vista='clase';
    return cargar(vista,contexto);
  }
  window.AppNavegacion={cargar,navegar,VISTAS};
})();
