window.SUPABASE_URL = "https://lztatgnlplpduiatmlrv.supabase.co";
window.SUPABASE_ANON_KEY = "sb_publishable_z_T7Y3yKqPdXLnvL3ltnQA_ZAPrXImZ";
