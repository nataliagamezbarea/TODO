/* GUARDAR RECUADRO DIRECTO (< 60 lineas) */

async function guardarRecuadroNuevoDirecto(tipo, it, pageNum, left, top, width, height) {
  const esColegio = (tipo === 'colegio');
  const esReflujo = (tipo === 'reflujo');
  showBlocker(esReflujo ? 'Guardando inicio de flujo...' : (esColegio ? 'Guardando colegio...' : 'Guardando nombre...'));
  try {
    let textoSeleccionado = '';
    if (!esReflujo) {
      try {
        const rt = await fetch('/api/extract_box_text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            grado: (it?._rama || grad), archivo: it.archivo, page_num: pageNum,
            left: left, top: top, width: width, height: height
          })
        });
        const dt = await rt.json();
        textoSeleccionado = (dt.text || '').trim();
      } catch (_e) {
        textoSeleccionado = '';
      }
    }

    await fetch('/api/recuadro', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        grado: (it?._rama || grad),
        archivo: it.archivo,
        tipo: tipo,
        page_num: pageNum,
        left: left, top: top, width: width, height: height,
        text: textoSeleccionado
      })
    });
    if (esColegio) await setCol(true);
    else if (!esReflujo) await setInt(true);
    limpiarRecuadrosDibujoSobrantes();
    hideBlocker();
    if (typeof openPos === 'function' && typeof POS !== 'undefined') openPos(POS);
    if (typeof refreshRightIframe === 'function') refreshRightIframe();
  } catch (err) {
    hideBlocker();
    console.error('Error al guardar el recuadro nuevo:', err);
  }
}


/* Selector de ramas: siempre conserva SELECCIONAR y permite TODAS las ramas */
function ensureAllBranchesOption(select) {
  if (!select) return;

  // SELECCIONAR siempre primero
  let defaultOpt = Array.from(select.options).find(o =>
    o.value === "" || o.dataset.defaultBranch === "1"
  );
  if (!defaultOpt) {
    defaultOpt = document.createElement("option");
    defaultOpt.value = "";
    defaultOpt.textContent = "SELECCIONAR";
    defaultOpt.dataset.defaultBranch = "1";
  }
  select.insertBefore(defaultOpt, select.firstChild);

  // TODAS LAS RAMAS siempre al FINAL
  Array.from(select.options).forEach(o => {
    if (o.dataset.allBranches === "1" || o.value === "__ALL_BRANCHES__") o.remove();
  });
  const allOpt = document.createElement("option");
  allOpt.value = "__ALL_BRANCHES__";
  allOpt.textContent = "— TODAS LAS RAMAS —";
  allOpt.dataset.allBranches = "1";
  select.appendChild(allOpt);
}
