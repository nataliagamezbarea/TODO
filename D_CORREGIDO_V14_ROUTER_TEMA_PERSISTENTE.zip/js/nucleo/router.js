/* Router de la aplicación.
 * Las URLs públicas son rutas lógicas:
 *   /inicio
 *   /asignaturas
 *   /asignatura/:id
 *   /clase/:id
 *   /apuntes
 * El router decide qué HTML mostrar.
 */
(function () {
  "use strict";

  const rutas = {
    "/": "inicio.html",
    "/inicio": "inicio.html",
    "/asignaturas": "asignaturas.html",
    "/asignatura": "asignatura.html",
    "/clase": "clase.html",
    "/apuntes": "apuntes.html"
  };

  function rutaActual() {
    return window.location.pathname.replace(/\/+$/, "") || "/";
  }

  function resolver(pathname) {
    const path = pathname.replace(/\/+$/, "") || "/";
    if (rutas[path]) return rutas[path];

    if (/^\/asignatura\/[^/]+$/.test(path)) return "asignatura.html";
    if (/^\/clase\/[^/]+$/.test(path)) return "clase.html";
    if (/^\/apuntes\/[^/]+$/.test(path)) return "apuntes.html";

    return null;
  }

  function navegar(url) {
    window.location.href = url;
  }

  window.AppRouter = {
    resolver,
    rutaActual,
    navegar,
    irA: function (ruta, id) {
      const base = String(ruta || "").replace(/^\/|\/$/g, "");
      const url = id == null ? "/" + base : "/" + base + "/" + encodeURIComponent(id);
      navegar(url);
    }
  };

  // Para Live Server / servidor estático: si entramos directamente en una ruta
  // lógica, cargamos el HTML real mediante fetch y reemplazamos el documento.
  document.addEventListener("DOMContentLoaded", async function () {
    const path = rutaActual();
    const archivo = resolver(path);
    if (!archivo) return;

    // Nunca interceptar si ya estamos en el archivo físico.
    if (path.endsWith(".html")) return;

    try {
      const respuesta = await fetch("/modulos/" + archivo, { cache: "no-store" });
      if (!respuesta.ok) return;

      const html = await respuesta.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");

      // Copiar atributos del <html> y contenido.
      for (const attr of Array.from(doc.documentElement.attributes)) {
        document.documentElement.setAttribute(attr.name, attr.value);
      }
      document.head.innerHTML = doc.head.innerHTML;
      document.body.innerHTML = doc.body.innerHTML;

      // Ejecutar scripts inline y externos del documento cargado.
      const scripts = Array.from(document.body.querySelectorAll("script"));
      for (const oldScript of scripts) {
        const s = document.createElement("script");
        for (const attr of Array.from(oldScript.attributes)) s.setAttribute(attr.name, attr.value);
        if (oldScript.src) s.src = oldScript.src;
        else s.textContent = oldScript.textContent;
        oldScript.replaceWith(s);
      }

      // Mantener el tema elegido después del render.
      window.TemaGlobal?.aplicar(localStorage.getItem("tema") || "light");
    } catch (error) {
      console.warn("[Router] No se pudo renderizar la ruta", path, error);
    }
  });
})();
