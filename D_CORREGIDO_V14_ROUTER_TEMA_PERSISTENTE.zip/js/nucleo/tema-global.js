/* Tema global persistente.
 * Una sola fuente de verdad: localStorage("tema") = "light" | "dark".
 * Se ejecuta antes de pintar la UI para evitar el flash de tema.
 */
(function () {
  "use strict";

  const CLAVE = "tema";
  const root = document.documentElement;

  function normalizar(valor) {
    return valor === "dark" ? "dark" : "light";
  }

  function obtenerTema() {
    const guardado = localStorage.getItem(CLAVE);
    if (guardado === "dark" || guardado === "light") return guardado;
    return root.classList.contains("modo-oscuro") ? "dark" : "light";
  }

  function aplicarTema(tema) {
    tema = normalizar(tema);
    root.dataset.tema = tema;
    root.classList.toggle("modo-oscuro", tema === "dark");
    root.classList.toggle("modo-claro", tema === "light");
    document.body?.classList.toggle("modo-oscuro", tema === "dark");
    document.body?.classList.toggle("modo-claro", tema === "light");
    localStorage.setItem(CLAVE, tema);

    const boton = document.getElementById("btn-modo-oscuro");
    if (boton) {
      const icono = boton.querySelector("i");
      if (icono) {
        icono.classList.toggle("fa-moon", tema !== "dark");
        icono.classList.toggle("fa-sun", tema === "dark");
      }
      boton.title = tema === "dark" ? "Modo claro" : "Modo oscuro";
      boton.setAttribute("aria-label", boton.title);
    }
  }

  window.TemaGlobal = {
    obtener: obtenerTema,
    aplicar: aplicarTema,
    alternar: function () {
      aplicarTema(obtenerTema() === "dark" ? "light" : "dark");
    }
  };

  // Aplicar inmediatamente al cargar el script.
  aplicarTema(obtenerTema());

  document.addEventListener("DOMContentLoaded", function () {
    aplicarTema(obtenerTema());
    const boton = document.getElementById("btn-modo-oscuro");
    if (boton && !boton.dataset.temaConectado) {
      boton.dataset.temaConectado = "true";
      boton.addEventListener("click", function () {
        window.TemaGlobal.alternar();
      });
    }
  });
})();
