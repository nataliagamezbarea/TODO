/* Navbar: el HTML se compila desde /componentes/navbar.html.
   Este archivo solo gestiona comportamiento (tema, navegación y sesión). */
(function () {
  function rutaInicio() {
    return location.pathname.includes("/modulos/") ? "../inicio.html" : "inicio.html";
  }

  function tema(oscuro) {
    document.documentElement.classList.toggle("modo-oscuro", oscuro);
    document.body.classList.toggle("modo-oscuro", oscuro);
  }

  function preparar() {
    const barra = document.getElementById("barra-superior");
    if (!barra) return;

    const ruta = rutaInicio();
    const inicio = document.getElementById("btn-inicio");
    const volver = document.getElementById("volver-atras");
    if (inicio) inicio.href = ruta;

    if (volver && !volver.dataset.listener) {
      volver.dataset.listener = "1";
      volver.addEventListener("click", (e) => {
        e.preventDefault();
        history.length > 1 ? history.back() : (location.href = ruta);
      });
    }

    const oscuro = localStorage.getItem("modo_oscuro") === "true";
    tema(oscuro);

    const botonTema = document.getElementById("btn-modo-oscuro");
    if (botonTema && !botonTema.dataset.listener) {
      botonTema.dataset.listener = "1";
      const actualizar = () => {
        botonTema.innerHTML = document.body.classList.contains("modo-oscuro")
          ? '<i class="fa-solid fa-sun"></i>'
          : '<i class="fa-solid fa-moon"></i>';
      };
      botonTema.addEventListener("click", () => {
        const nuevo = !document.body.classList.contains("modo-oscuro");
        tema(nuevo);
        localStorage.setItem("modo_oscuro", String(nuevo));
        actualizar();
      });
      actualizar();
    }

    const salir = document.getElementById("btn-cerrar-sesion");
    if (salir && !salir.dataset.listener) {
      salir.dataset.listener = "1";
      salir.addEventListener("click", async () => {
        sessionStorage.clear();
        try { await window.supabaseClient?.auth?.signOut(); } catch (_) {}
        location.replace(location.pathname.includes("/modulos/")
          ? "iniciar-sesion.html"
          : "modulos/iniciar-sesion.html");
      });
    }

    window.__alternarModoOscuro = () => botonTema?.click();
    window.dispatchEvent(new CustomEvent("navbar-lista"));

    if (window.asegurarModoEdicionBoton) window.asegurarModoEdicionBoton();
    if (window.inicializarNavbarMovil) window.inicializarNavbarMovil({});
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", preparar, { once: true });
  } else {
    preparar();
  }

  window.ComponenteNavbar = { inicializar: preparar };
})();
