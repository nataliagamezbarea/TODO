(() => {
  function volverAlInicio(evento) {
    evento.preventDefault();
    // No tocamos modo_oscuro ni la rama aquí. El router principal decidirá
    // el destino: si hay rama persistida entra directamente en ella; si no,
    // muestra el selector.
    try {
      const contexto = JSON.parse(localStorage.getItem("visor_contexto") || "{}");
      localStorage.setItem("visor_contexto", JSON.stringify({ ...contexto, abrirLista: true }));
    } catch (_) {}
    if (window.AppViews?.irInicio) {
      window.AppViews.irInicio();
      return;
    }
    location.assign("/");
  }

  function volverDesdeVisor(evento) {
    evento.preventDefault();
    const documento = document.getElementById("ov");
    if (documento?.classList.contains("on") && typeof window.closeOv === "function") {
      window.closeOv();
      return;
    }
    const destino = evento.currentTarget.dataset.returnPath || "/";
    location.assign(destino);
  }

  document.addEventListener("DOMContentLoaded", () => {
    const inicio = document.getElementById("btn-inicio");
    const atras = document.getElementById("volver-atras");
    if (inicio) inicio.onclick = volverAlInicio;
    if (atras) atras.onclick = volverDesdeVisor;
  }, { once: true });
})();
