// Exporta el proyecto entero (código fuente + datos de los 2 repos de
// GitHub, con TODAS las ramas y TODOS los archivos, sin filtrar por
// visibilidad de invitado) en un único ZIP que se puede abrir en local sin
// depender de GitHub ni de Supabase. Solo visible para el admin.
//
// Las ramas del repo privado y del repo público NO se fusionan: cada una se
// guarda en su propia carpeta (datos-export/privado/<rama> y
// datos-export/publico/<rama>). Si una rama existe en los dos repos con el
// mismo nombre, gana la del privado a la hora de leerla en local; es un
// caso raro y no afecta a nada más.

window.ExportadorProyecto = (() => {
  // Código fuente de la app: todo lo necesario para que la web funcione,
  // sin nada de configuración sensible (.env, workflows, sql...).
  const ARCHIVOS_ESTATICOS = [
    "classroom_icon.png",
    "css/ajustes.css",
    "css/apuntes_practicas_ejercicios_tareas.css",
    "css/archivos.css",
    "css/asignatura.css",
    "css/botones.css",
    "css/global.css",
    "css/index.css",
    "css/login.css",
    "css/navbar_movil.css",
    "css/notificador.css",
    "css/popover.css",
    "css/portada_emoji.css",
    "css/trimestre.css",
    "css/visor.css",
    "img/captura_representativa.jpg",
    "img/portada.jpg",
    "js/componentes/ajustes.js",
    "js/componentes/emojis.js",
    "js/componentes/navbar.js",
    "js/componentes/navbar/navbar_modo_edicion.js",
    "js/componentes/navbar/navbar_movil.js",
    "js/descargas/exportador_proyecto.js",
    "js/descargas/notificador.js",
    "js/descargas/recolector_urls.js",
    "js/descargas/ziper.js",
    "js/modales/gestor_archivos_modal.js",
    "js/modales/previsualizador.js",
    "js/nucleo/anonimizador.js",
    "js/nucleo/auth.js",
    "js/nucleo/permisos.js",
    "js/permisos/crypto.js",
    "js/permisos/github.js",
    "js/permisos/supabase.js",
    "js/permisos/visibilidad.js",
    "js/renderizadores/apuntes_practicas_ejercicios_tareas.js",
    "js/renderizadores/mostrar_archivos.js",
    "js/renderizadores/mostrar_datos.js",
    "js/servicios/estado.js",
    "js/servicios/informacion.js",
    "js/servicios/rama.js",
    "js/servicios/trimestres.js",
    "js/vistas/clase.js",
    "js/vistas/index_rama.js",
    "js/vistas/login.js",
    "js/vistas/trimestre.js",
    "js/vistas/volver_atras.js",
  ];

  // HTML a los que hay que inyectarles el arranque de "modo local".
  const HTML_A_INYECTAR = [
    "index.html",
    "modulos/apuntes_practicas_ejercicios_tareas.html",
    "modulos/asignatura.html",
    "modulos/asignaturas.html",
    "modulos/clase.html",
    "modulos/login.html",
  ];

  const CSV_Y_JSON = ["APUNTES.csv", "EJERCICIOS_PRACTICAS_PROYECTOS.csv", "informacion.json"];

  const LEEME = `EXPORTACIÓN LOCAL — GRADOS_INFORMATICOS
=========================================

Esta carpeta es una copia completa e independiente del proyecto: el código
de la web + todos los datos y archivos de los dos repositorios de GitHub
(privado y público), con todas las ramas. No necesita internet, GitHub ni
Supabase para funcionar.

CÓMO ABRIRLA (IMPORTANTE):
No hagas doble clic en index.html directamente. Los navegadores bloquean
la lectura de archivos locales cuando se abren así (política de CORS de
file://) y la web no podrá cargar los CSV. Tienes que servirla con un
pequeño servidor local:

  1. Si tienes Python instalado:
       - Windows: doble clic en "iniciar-servidor-local.bat"
       - Mac/Linux: abre una terminal aquí y ejecuta
         ./iniciar-servidor-local.sh
  2. Abre en el navegador: http://localhost:8000

Se abre en modo lectura total (como el admin), sin login: es tu copia
personal para verla y navegarla offline.

ESTRUCTURA:
  datos-export/privado/<rama>/...   -> datos del repo privado
  datos-export/publico/<rama>/...   -> datos del repo público (invitados)
  datos-export/mapa_ramas.json      -> qué rama viene de qué repo
  datos-export/ramas_todas.json     -> listado de ramas para el selector

Las ramas de ambos repos NO se combinan entre sí: cada una vive en su
carpeta. Si el mismo nombre de rama existiera en los dos repos, en local
se usa la del privado.
`;

  const SCRIPT_SH = `#!/bin/sh
cd "$(dirname "$0")"
echo "Sirviendo el proyecto en http://localhost:8000 (Ctrl+C para parar)"
python3 -m http.server 8000 || python -m http.server 8000
`;

  const SCRIPT_BAT = `@echo off
cd /d "%~dp0"
echo Sirviendo el proyecto en http://localhost:8000 (Ctrl+C para parar)
py -m http.server 8000 || python -m http.server 8000
pause
`;

  const inyectarModoLocal = (html, esModulo) => {
    const prefijo = esModulo ? "../" : "";
    const tag = `\n<script>window.MODO_LOCAL = true;</script>\n<script src="${prefijo}js/nucleo/modo_local.js"></script>\n</body>`;
    return /<\/body>/i.test(html) ? html.replace(/<\/body>/i, tag) : html + tag;
  };

  const incluirArchivoEstatico = async (zip, ruta) => {
    try {
      const res = await fetch(ruta);
      if (!res.ok) return;
      zip.file(ruta, await res.blob());
    } catch (e) {
      console.error("No se pudo incluir en el export:", ruta, e);
    }
  };

  const incluirCodigoFuente = async (zip) => {
    for (const ruta of ARCHIVOS_ESTATICOS) {
      await incluirArchivoEstatico(zip, ruta);
    }

    // js/nucleo/modo_local.js: se descarga tal cual (ya viene en el repo,
    // no hay que generarlo) para que quede embebido en el export.
    await incluirArchivoEstatico(zip, "js/nucleo/modo_local.js");

    // El nombre del script SUPABASETOKEN_*.js cambia en cada build, así
    // que se localiza dinámicamente en la propia página.
    const scriptToken = document.querySelector('script[src*="SUPABASETOKEN_"]');
    if (scriptToken) {
      let src = scriptToken.getAttribute("src") || "";
      src = src.replace(/^\.?\//, "").replace(/^\.\.\//, "");
      if (src) await incluirArchivoEstatico(zip, src);
    }

    for (const ruta of HTML_A_INYECTAR) {
      try {
        const res = await fetch(ruta);
        if (!res.ok) continue;
        const texto = await res.text();
        zip.file(ruta, inyectarModoLocal(texto, ruta.startsWith("modulos/")));
      } catch (e) {
        console.error("No se pudo incluir/inyectar:", ruta, e);
      }
    }
  };

  const cabecerasGitHub = (token) => {
    const h = { Accept: "application/vnd.github.raw", "User-Agent": "grados-informaticos" };
    if (token) h.Authorization = `Bearer ${token}`;
    return h;
  };

  const listarRamasRepoRemoto = async (repo, token) => {
    if (!repo) return [];
    try {
      const headers = { Accept: "application/vnd.github+json" };
      if (token) headers.Authorization = `Bearer ${token}`;
      const res = await fetch(`https://api.github.com/repos/${repo}/branches?per_page=100`, { headers });
      if (!res.ok) return [];
      const datos = await res.json();
      return (Array.isArray(datos) ? datos : [])
        .map((b) => b.name)
        .filter((n) => n && n.toLowerCase() !== "master");
    } catch (e) {
      return [];
    }
  };

  const leerTextoRepo = async (repo, token, rama, ruta) => {
    try {
      const partes = String(ruta).replace(/^\.?\//, "").split("/").map(encodeURIComponent).join("/");
      const res = await fetch(
        `https://api.github.com/repos/${repo}/contents/${partes}?ref=${encodeURIComponent(rama)}`,
        { headers: cabecerasGitHub(token) }
      );
      if (!res.ok) return null;
      return await res.text();
    } catch (e) {
      return null;
    }
  };

  const leerBlobRepo = async (repo, token, rama, ruta) => {
    try {
      const partes = String(ruta).replace(/^\.?\//, "").split("/").map(encodeURIComponent).join("/");
      const res = await fetch(
        `https://api.github.com/repos/${repo}/contents/${partes}?ref=${encodeURIComponent(rama)}`,
        { headers: cabecerasGitHub(token) }
      );
      if (!res.ok) return null;
      return await res.blob();
    } catch (e) {
      return null;
    }
  };

  // Todos los ARCHIVO de APUNTES.csv + EJERCICIOS_PRACTICAS_PROYECTOS.csv de
  // una rama, sin filtrar por visibilidad (export completo del admin).
  const recogerUrlsRama = async (repo, token, rama) => {
    const vistas = new Set();
    for (const archivo of ["APUNTES.csv", "EJERCICIOS_PRACTICAS_PROYECTOS.csv"]) {
      const texto = await leerTextoRepo(repo, token, rama, archivo);
      if (!texto) continue;
      try {
        const filas = Papa.parse(texto, { header: true, skipEmptyLines: true, delimiter: ",", quotes: true }).data;
        filas.forEach((f) => {
          String(f.ARCHIVO || "")
            .split(/[,;]/)
            .map((u) => u.trim())
            .filter(Boolean)
            .forEach((u) => vistas.add(u));
        });
      } catch (e) {}
    }
    return Array.from(vistas);
  };

  const exportarRepo = async (zip, origen, repo, token, mapaRamas, onEstado) => {
    if (!repo) return [];
    const ramas = await listarRamasRepoRemoto(repo, token);

    for (let i = 0; i < ramas.length; i++) {
      const rama = ramas[i];
      if (!(rama in mapaRamas)) mapaRamas[rama] = origen;
      const base = `datos-export/${origen}/${rama}`;

      onEstado && onEstado(`[${origen}] ${rama}: leyendo CSV/JSON...`, i, ramas.length);
      for (const archivo of CSV_Y_JSON) {
        const texto = await leerTextoRepo(repo, token, rama, archivo);
        if (texto !== null) zip.file(`${base}/${archivo}`, texto);
      }

      const urls = await recogerUrlsRama(repo, token, rama);
      for (let j = 0; j < urls.length; j++) {
        onEstado && onEstado(`[${origen}] ${rama}: archivo ${j + 1}/${urls.length}...`, i, ramas.length);
        const blob = await leerBlobRepo(repo, token, rama, urls[j]);
        if (blob) {
          const limpia = String(urls[j]).replace(/^\.?\//, "");
          zip.file(`${base}/archivos/${limpia}`, blob);
        }
      }
    }
    return ramas;
  };

  const exportarProyectoCompleto = async (onEstado) => {
    if (!(window.Permisos && window.Permisos.esAdmin)) {
      throw new Error("Solo el admin puede exportar el proyecto.");
    }

    const JSZip = window.JSZip || (window.cargarJSZip ? await window.cargarJSZip() : null);
    if (!JSZip) throw new Error("No se pudo cargar JSZip.");
    const zip = new JSZip();

    onEstado && onEstado("Empaquetando código fuente de la web...", 0, 1);
    await incluirCodigoFuente(zip);

    const config = window.GITHUB_CONFIG || {};
    const token = typeof config.obtenerTokenSeguro === "function" ? config.obtenerTokenSeguro() : (config.token || "");
    const repoPrivado = (config.repo || "").trim();
    const repoPublico = (config.repoPublico || "").trim();

    const mapaRamas = {};

    onEstado && onEstado("Descargando datos del repositorio privado...", 0, 1);
    const ramasPrivado = await exportarRepo(zip, "privado", repoPrivado, token, mapaRamas, onEstado);

    let ramasPublico = [];
    if (repoPublico && repoPublico !== repoPrivado) {
      onEstado && onEstado("Descargando datos del repositorio público...", 0, 1);
      ramasPublico = await exportarRepo(zip, "publico", repoPublico, token, mapaRamas, onEstado);
    }

    const todasRamas = Array.from(new Set([...ramasPrivado, ...ramasPublico])).sort();
    zip.file("datos-export/mapa_ramas.json", JSON.stringify(mapaRamas, null, 2));
    zip.file("datos-export/ramas_todas.json", JSON.stringify(todasRamas, null, 2));

    zip.file("LEEME-LOCAL.txt", LEEME);
    zip.file("iniciar-servidor-local.sh", SCRIPT_SH);
    zip.file("iniciar-servidor-local.bat", SCRIPT_BAT);

    onEstado && onEstado("Generando el ZIP final...", 0, 1);
    const blob = await zip.generateAsync({ type: "blob" });
    const objUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objUrl;
    a.download = `grados-informaticos-export-${new Date().toISOString().slice(0, 10)}.zip`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objUrl), 60000);

    onEstado && onEstado("¡Exportación completada!", 1, 1);
  };

  // Botón, solo admin: se añade dentro del panel de Ajustes.
  const montarBoton = () => {
    const cuerpo = document.querySelector("#panel-ajustes .cuerpo-ajustes");
    if (!cuerpo || cuerpo.querySelector("#btn-exportar-proyecto")) return;
    if (!(window.Permisos && window.Permisos.esAdmin)) return;

    const seccion = document.createElement("div");
    seccion.className = "seccion-ajustes-titulo";
    seccion.innerHTML = '<i class="fa-solid fa-box-archive seccion-ajustes-icono"></i>Exportar';

    const btn = document.createElement("button");
    btn.type = "button";
    btn.id = "btn-exportar-proyecto";
    btn.className = "btn-descarga-masiva";
    btn.innerHTML = '<i class="fa-solid fa-download"></i> Exportar proyecto completo (offline)';
    btn.title = "Descarga la web + todos los datos de ambos repos, en un ZIP para ver en local";

    btn.addEventListener("click", async () => {
      btn.disabled = true;
      const original = btn.innerHTML;
      try {
        await exportarProyectoCompleto((estado) => {
          btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> ${estado}`;
        });
        btn.innerHTML = '<i class="fa-solid fa-check icono-exito"></i> ¡Listo! Descarga iniciada';
      } catch (e) {
        console.error(e);
        btn.innerHTML = '<i class="fa-solid fa-circle-xmark icono-error"></i> Error al exportar';
      } finally {
        setTimeout(() => {
          btn.disabled = false;
          btn.innerHTML = original;
        }, 3000);
      }
    });

    cuerpo.appendChild(seccion);
    cuerpo.appendChild(btn);
  };

  const asegurarBoton = async () => {
    try {
      if (window.Permisos && typeof window.Permisos.asegurarSesion === "function") {
        await window.Permisos.asegurarSesion();
      }
    } catch (e) {}
    if (!(window.Permisos && window.Permisos.esAdmin)) return;

    // El panel de Ajustes se crea de forma perezosa (al primer clic), así
    // que se intenta montar el botón y, si el panel aún no existe, se
    // reintenta cuando se abra.
    montarBoton();
    document.addEventListener("click", (e) => {
      if (e.target.closest && e.target.closest("#boton-ajustes")) {
        setTimeout(montarBoton, 0);
      }
    });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", asegurarBoton);
  } else {
    asegurarBoton();
  }

  return { exportarProyectoCompleto };
})();


/* Selector de ramas: siempre conserva SELECCIONAR y permite TODAS las ramas */
function ensureAllBranchesOption(select) {
  if (!select) return;

  // SELECCIONAR siempre primero
  let defaultOpt = Array.from(select.options).find(o =>
    o.value === "" || o.dataset.defaultBranch === "1"
  );
  if (!defaultOpt) {
    defaultOpt = document.createElement("option");
    defaultOpt.value = "";
    defaultOpt.textContent = "SELECCIONAR";
    defaultOpt.dataset.defaultBranch = "1";
  }
  select.insertBefore(defaultOpt, select.firstChild);

  // TODAS LAS RAMAS siempre al FINAL
  Array.from(select.options).forEach(o => {
    if (o.dataset.allBranches === "1" || o.value === "__ALL_BRANCHES__") o.remove();
  });
  const allOpt = document.createElement("option");
  allOpt.value = "__ALL_BRANCHES__";
  allOpt.textContent = "— TODAS LAS RAMAS —";
  allOpt.dataset.allBranches = "1";
  select.appendChild(allOpt);
}
