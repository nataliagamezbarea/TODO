(() => {
  // La interfaz y la navbar deben ser utilizables desde el primer frame.
  // La autenticación/Supabase se resuelve en segundo plano.
  document.documentElement.style.visibility = "visible";
  document.documentElement.classList.add("auth-cargando");

  if (typeof localStorage !== "undefined" && localStorage.getItem("modo_oscuro") === "true") {
    if (typeof document !== "undefined" && document.documentElement) {
      document.documentElement.classList.add("modo-oscuro");
    }
  }

  if (!window.SUPABASE_URL) window.SUPABASE_URL = "https://lztatgnlplpduiatmlrv.supabase.co";
  if (!window.SUPABASE_ANON_KEY) window.SUPABASE_ANON_KEY = "sb_publishable_z_T7Y3yKqPdXLnvL3ltnQA_ZAPrXImZ";

  if (!window.GITHUB_CONFIG) {
    window.GITHUB_CONFIG = {
      repo: "nataliagamezbarea/GRADOS_INFORMATICOS",
      token: "",
    };
  } else if (!window.GITHUB_CONFIG.repo) {
    window.GITHUB_CONFIG.repo = "nataliagamezbarea/GRADOS_INFORMATICOS";
  }

  if (typeof document !== "undefined" && !document.querySelector('link[href*="font-awesome"]') && !document.querySelector('link[href*="fontawesome"]')) {
    const link = document.createElement("link");
    link.id = "fa-cdn";
    link.rel = "stylesheet";
    link.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css";
    document.head.appendChild(link);
  }

  if (typeof document !== "undefined" && !document.getElementById("emojis-script")) {
    const rutaActual = window.location.pathname;
    const enModulos = rutaActual.includes("/modulos/");
    const enVisorAdmin = rutaActual.includes("/visor-admin/");
    const scriptEmoji = document.createElement("script");
    scriptEmoji.id = "emojis-script";
    scriptEmoji.src = enModulos || enVisorAdmin ? "../js/componentes/emojis.js" : "js/componentes/emojis.js";
    document.head.appendChild(scriptEmoji);
  }

  const credencialesListas = true;
  const esPaginaLogin = /login\.html/.test(window.location.pathname);
  const esPaginaVisor = /(?:visor\.html|visor-admin\/index\.html)$/.test(window.location.pathname);
  const redirigir = (destino) => window.location.replace(destino);
  const rutaLogin = () => {
    const p = window.location.pathname.replace(/\\/g, "/");
    if (p.includes("/visor-admin/")) return "../modulos/login.html";
    if (p.includes("/modulos/")) return "login.html";
    return "modulos/login.html";
  };

  const iniciar = async () => {
    try {
      if (!credencialesListas) {
        throw new Error("Configura SUPABASE_URL y SUPABASE_ANON_KEY en js/supabase-config.js");
      }

      // La API de datos de Supabase debe usar por defecto nuestro schema.
      // Supabase JS enviará automáticamente: Accept-Profile: grados-informaticos
      // en las consultas hechas con cliente.from(...).
      const supabase = window.supabase.createClient(
        window.SUPABASE_URL,
        window.SUPABASE_ANON_KEY,
        {
          db: { schema: "grados-informaticos" }
        }
      );
      window.supabaseClient = supabase;

      let { data: { session } } = await supabase.auth.getSession();
      if (!session && window.location.hash.includes("access_token")) {
        for (let i = 0; i < 20; i++) {
          await new Promise((r) => setTimeout(r, 100));
          const res = await supabase.auth.getSession();
          if (res.data?.session) {
            session = res.data.session;
            break;
          }
        }
      }

      if (session?.user) {
        let esAdminValido = false;
        try {
          if (window.Permisos) {
            esAdminValido = await window.Permisos.verificarAdmin(session.user);
          }
        } catch (e) {}

        if (!esAdminValido) {
          sessionStorage.removeItem("esInvitado");
          await supabase.auth.signOut();
          session = null;

          if (esPaginaLogin) {
            const errorBox = document.getElementById("mensaje-error");
            if (errorBox) {
              errorBox.textContent = "Acceso restringido: Esta cuenta no pertenece a un administrador ni colaborador del repositorio. Debes pulsar 'Entrar como Invitado'.";
              errorBox.hidden = false;
            }
          }
        } else {
          sessionStorage.removeItem("esInvitado");
          if (window.Permisos) {
            try {
              await window.Permisos.cargoSesion();
              // Primera inicialización: si los CSV aún no están en el repo privado,
              // se copian desde el repositorio real. Si faltan en el público, se
              // crean vacíos con las mismas columnas. Solo se ejecuta como admin.
              if (window.PermisosVisibilidad?.asegurarCsvIniciales) {
                await window.PermisosVisibilidad.asegurarCsvIniciales();
              }
            } catch (e) {}
          }
        }

        // Imprimir estado de admin
        if (window.Permisos) {
          try {
          } catch (e) {}
        }
      }

      const esInvitado = sessionStorage.getItem("esInvitado") === "true";
      const tieneAcceso = Boolean(session || esInvitado);

      // Redirección inmediata si no tiene acceso y no está en la página de login
      if (!esPaginaLogin && !tieneAcceso) {
        const enModulos = window.location.pathname.includes("/modulos");
        redirigir(rutaLogin());
        return;
      }

      const MSG_BLOQUEO =
        "Acceso restringido: Esta cuenta no pertenece a un administrador ni colaborador del repositorio. " +
        "En este momento el material está en revisión o actualización y el acceso temporal a invitados está desactivado. " +
        "Inténtalo de nuevo más tarde. Si necesitas acceso, contacta con la propietaria del repositorio.";

      if (window.Permisos && typeof window.Permisos.cargarAjustesServidor === "function") {
        await window.Permisos.cargarAjustesServidor();
      }

      if (esInvitado && window.Permisos && window.Permisos.invitadosActivos === false) {
        sessionStorage.removeItem("esInvitado");
        if (esPaginaLogin) {
          document.documentElement.style.visibility = "visible";
          document.documentElement.classList.remove("auth-cargando");
          const errorBox = document.getElementById("mensaje-error");
          if (errorBox) {
            errorBox.textContent = MSG_BLOQUEO;
            errorBox.hidden = false;
          }
          return;
        }
        const enModulos = window.location.pathname.includes("/modulos");
        redirigir(rutaLogin());
        return;
      }

      if (esPaginaLogin && tieneAcceso) {
        const enModulos = window.location.pathname.includes("/modulos");
        redirigir(enModulos ? "../index.html" : "index.html");
        return;
      }

      document.documentElement.style.visibility = "visible";
      document.documentElement.classList.remove("auth-cargando");
      window.sesionActual = session;

      if (!esPaginaLogin && !esPaginaVisor) {
        if (window.ComponenteNavbar && typeof window.ComponenteNavbar.inicializar === "function") {
          window.ComponenteNavbar.inicializar();
        }
      }
    } catch (error) {
      if (!esPaginaLogin) {
        const enModulos = window.location.pathname.includes("/modulos");
        redirigir(rutaLogin());
        return;
      }
      document.documentElement.style.visibility = "visible";
      document.documentElement.classList.remove("auth-cargando");
    }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", iniciar);
  } else {
    iniciar();
  }
})();
